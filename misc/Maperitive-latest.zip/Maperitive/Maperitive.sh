#!/bin/sh
mono --desktop Maperitive.exe "$@"
