# -*- coding: utf-8 -*-
from maperipy import Map

Map.layers[0].attribution = "This layer is mine, all mine! � mine"
