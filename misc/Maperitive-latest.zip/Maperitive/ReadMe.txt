﻿Maperitive Readme
-----------------

Maperitive is a desktop aplication for interactive mapping using OpenStreetMap data and other sources.

NOTE: While it will probably not burn your computer or kill your pets, Maperitive is highly undocumented 
and almost certainly full of bugs. Also, it's not very user-friendly.
Keep in mind that a lot of things will probably change (and hopefully improve) in the near future.

You can submit bugs, annoyances, suggestions and praises via mail to support@maperitive.net
There is also an automatic bug reporting function in Maperitive.

And thanks for being brave and trying it out!

Prerequisites
-------------
Windows: Maperitive should be able to run on any Windows OS supporting the .NET 4.0. 
You can download it via http://www.hanselman.com/smallestdotnet/

Linux & Mac: Maperitive needs Mono (http://www.go-mono.com/mono-downloads/download.html). It has been tested on Mono v2.6.1

Installing
------------
Simply unzip the package to a place of your choice.

Starting
--------
Windows: Run "Maperitive.exe" file.
Linux & Mac: Run the "Maperitive.sh" shell script. You may need to enable executable permissions first.
